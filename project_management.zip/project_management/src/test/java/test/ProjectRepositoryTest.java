package test;
import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import com.projectmanagement.dao.IProjectRepository;
import com.projectmanagement.dao.ProjectRepositoryImpl;
import com.projectmanagement.exception.EmployeeNotFoundException;
import com.projectmanagement.exception.ProjectNotFoundException;
import com.projectmanagement.model.Employee;
import com.projectmanagement.model.Project;
import com.projectmanagement.model.Task;

public class ProjectRepositoryTest {


    private IProjectRepository repository;

    @BeforeEach
    public void setUp() {
        repository = new ProjectRepositoryImpl();
    }

    @Test
    public void testCreateEmployee() {
        Employee employee = new Employee(1, "John Doe", "Developer", 'M', 50000, 0);
        assertTrue(repository.createEmployee(employee), "Employee should be created successfully");
    }

    @Test
    public void testCreateTask() {
        Task task = new Task(1, "Task 1", 1, 1, "Assigned");
        assertTrue(repository.createTask(task), "Task should be created successfully");
    }

    @Test
    public void testAssignProjectToEmployee() throws EmployeeNotFoundException, ProjectNotFoundException {
        Employee employee = new Employee(2, "Jane Doe", "Tester", 'F', 60000, 0);
        repository.createEmployee(employee);
        Project project = new Project(2, "Project 2", "Description", new Date(0), "started");
        repository.createProject(project);
        assertTrue(repository.assignProjectToEmployee(2, 2), "Project should be assigned to employee successfully");
    }

    @Test
    public void testGetAllTasks() {
        Employee employee = new Employee(3, "Alice", "Manager", 'F', 70000, 1);
        repository.createEmployee(employee);
        Task task1 = new Task(2, "Task 2", 1, 3, "Assigned");
        Task task2 = new Task(3, "Task 3", 1, 3, "Assigned");
        repository.createTask(task1);
        repository.createTask(task2);
        List<Task> tasks = repository.getAllTasks(3, 1);
        assertEquals(2, tasks.size(), "Should return all tasks assigned to employee within project");
    }

    @Test
    public void testEmployeeNotFoundException() {
        EmployeeNotFoundException thrown = assertThrows(EmployeeNotFoundException.class, () -> {
            repository.assignProjectToEmployee(1, 999);  // assuming 999 does not exist
        });
        assertEquals("Employee with ID 999 not found.", thrown.getMessage());
    }

    @Test
    public void testProjectNotFoundException() {
        ProjectNotFoundException thrown = assertThrows(ProjectNotFoundException.class, () -> {
            repository.assignProjectToEmployee(999, 1);  // assuming 999 does not exis
        });
        assertEquals("Project with ID 999 not found.", thrown.getMessage());
    }
}
