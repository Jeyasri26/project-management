package com.projectmanagement.dao;

import java.util.List;

import com.projectmanagement.exception.EmployeeNotFoundException;
import com.projectmanagement.exception.ProjectNotFoundException;
import com.projectmanagement.model.Employee;
import com.projectmanagement.model.Project;
import com.projectmanagement.model.Task;

public interface IProjectRepository {

    
    boolean createEmployee(Employee emp);
    boolean createProject(Project pj);
    boolean createTask(Task task);

    boolean assignProjectToEmployee(int projectId, int employeeId) throws EmployeeNotFoundException, ProjectNotFoundException;
    boolean assignTaskInProjectToEmployee(int taskId, int projectId, int employeeId) throws EmployeeNotFoundException, ProjectNotFoundException;

    boolean deleteEmployee(int userId) throws EmployeeNotFoundException;
    boolean deleteProject(int projectId) throws ProjectNotFoundException;

    List<Task> getAllTasks(int empId, int projectId);
}
