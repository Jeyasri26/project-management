package com.projectmanagement.dao;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;

import com.projectmanagement.model.Employee;
import com.projectmanagement.model.Project;
import com.projectmanagement.model.Task;
import com.projectmanagement.util.*;
import com.projectmanagement.exception.*;

public class ProjectRepositoryImpl implements IProjectRepository{

    private Connection connection;

    public ProjectRepositoryImpl() {
        this.connection = DBUtil.getConnect();
    }

    @Override
    public boolean createEmployee(Employee employee) {
        String sql = "INSERT INTO Employee (employee_id, name, designation, gender, salary, project_id) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, employee.getEmployeeId());
            pstmt.setString(2, employee.getName());
            pstmt.setString(3, employee.getDesignation());
            pstmt.setString(4, String.valueOf(employee.getGender()));
            pstmt.setDouble(5, employee.getSalary());
            pstmt.setInt(6, employee.getProjectId());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean createProject(Project project) {
        String sql = "INSERT INTO Project (project_id, project_name, description, start_date, status) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, project.getProjectId());
            pstmt.setString(2, project.getProjectName());
            pstmt.setString(3, project.getDescription());
            pstmt.setDate(4, new java.sql.Date(project.getStartDate().getTime()));
            pstmt.setString(5, project.getStatus());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean createTask(Task task) {
        String sql = "INSERT INTO Task (task_id, task_name, project_id, employee_id, status) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, task.getTaskId());
            pstmt.setString(2, task.getTaskName());
            pstmt.setInt(3, task.getProjectId());
            pstmt.setInt(4, task.getEmployeeId());
            pstmt.setString(5, task.getStatus());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean assignProjectToEmployee(int projectId, int employeeId) throws EmployeeNotFoundException, ProjectNotFoundException {
        if (!isEmployeeExists(employeeId)) {
            throw new EmployeeNotFoundException("Employee with id " + employeeId + " not found.");
        }
        if (!isProjectExists(projectId)) {
            throw new ProjectNotFoundException("Project with id " + projectId + " not found.");
        }
        String sql = "UPDATE Employee SET project_id = ? WHERE employee_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, projectId);
            pstmt.setInt(2, employeeId);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean assignTaskInProjectToEmployee(int taskId, int projectId, int employeeId) throws EmployeeNotFoundException, ProjectNotFoundException {
        if (!isEmployeeExists(employeeId)) {
            throw new EmployeeNotFoundException("Employee with id " + employeeId + " not found.");
        }
        if (!isProjectExists(projectId)) {
            throw new ProjectNotFoundException("Project with id " + projectId + " not found.");
        }
        String sql = "UPDATE Task SET employee_id = ? WHERE task_id = ? AND project_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, employeeId);
            pstmt.setInt(2, taskId);
            pstmt.setInt(3, projectId);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteEmployee(int employeeId) throws EmployeeNotFoundException {
        if (!isEmployeeExists(employeeId)) {
            throw new EmployeeNotFoundException("Employee with id " + employeeId + " not found.");
        }
        String sql = "DELETE FROM Employee WHERE employee_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, employeeId);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteProject(int projectId) throws ProjectNotFoundException {
        if (!isProjectExists(projectId)) {
            throw new ProjectNotFoundException("Project with id " + projectId + " not found.");
        }
        String sql = "DELETE FROM Project WHERE project_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, projectId);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Task> getAllTasks(int employeeId, int projectId) {
        String sql = "SELECT * FROM Task WHERE employee_id = ? AND project_id = ?";
        List<Task> tasks = new ArrayList<>();
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, employeeId);
            pstmt.setInt(2, projectId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Task task = new Task();
                task.setTaskId(rs.getInt("task_id"));
                task.setTaskName(rs.getString("task_name"));
                task.setProjectId(rs.getInt("project_id"));
                task.setEmployeeId(rs.getInt("employee_id"));
                task.setStatus(rs.getString("status"));
                tasks.add(task);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tasks;
    }

    private boolean isEmployeeExists(int employeeId) {
        String sql = "SELECT 1 FROM Employee WHERE employee_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, employeeId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean isProjectExists(int projectId) {
        String sql = "SELECT 1 FROM Project WHERE project_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, projectId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}