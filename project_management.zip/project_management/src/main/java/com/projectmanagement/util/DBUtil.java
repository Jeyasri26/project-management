package com.projectmanagement.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
    private static Connection connection = null;
    
    private DBUtil() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            String hostname = PropertyUtil.getPropertyString("hostname");
            String dbname = PropertyUtil.getPropertyString("dbname");
            String username = PropertyUtil.getPropertyString("username");
            String password = PropertyUtil.getPropertyString("password");
            String port = PropertyUtil.getPropertyString("port");
            
            String url = "jdbc:mysql://" + hostname + ":" + port + "/" + dbname;
            
            connection = DriverManager.getConnection(url, username, password);
            
            System.out.println("Connected to the database");
            
        } catch(Exception e) {
            System.out.println(e);
        }
    }
    
    public static Connection getConnect() {
        if (connection== null) {
            new DBUtil();
        }
        return connection;
    }
    
}
