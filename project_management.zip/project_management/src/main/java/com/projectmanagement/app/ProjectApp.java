package com.projectmanagement.app;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.projectmanagement.dao.IProjectRepository;
import com.projectmanagement.dao.ProjectRepositoryImpl;
import com.projectmanagement.exception.EmployeeNotFoundException;
import com.projectmanagement.exception.ProjectNotFoundException;
import com.projectmanagement.model.Employee;
import com.projectmanagement.model.Project;
import com.projectmanagement.model.Task;

public class ProjectApp {

        private static IProjectRepository repository = new ProjectRepositoryImpl();
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            
            while (true) {
                System.out.println("Choose an operation:");
                System.out.println("1. Add Employee");
                System.out.println("2. Add Project");
                System.out.println("3. Add Task");
                System.out.println("4. Assign project to employee");
                System.out.println("5. Assign task within a project to employee");
                System.out.println("6. Delete Employee");
                System.out.println("7. Delete Project");
                System.out.println("8. List all tasks in a project assigned to an employee");
                System.out.println("9. Exit");
    
                System.out.println("Enter your choice: ");         
                int choice = scanner.nextInt();
                scanner.nextLine();
    
                try {
                    switch (choice) {
                        case 1:
                            addEmployee(scanner);
                            break;
                        case 2:
                            addProject(scanner);
                            break;
                        case 3:
                            addTask(scanner);
                            break;
                        case 4:
                            assignProjectToEmployee(scanner);
                            break;
                        case 5:
                            assignTaskInProjectToEmployee(scanner);
                            break;
                        case 6:
                            deleteEmployee(scanner);
                            break;
                        case 7:
                            deleteProject(scanner);
                            break;
                        case 8:
                            listAllTasks(scanner);
                            break;
                        case 9:
                            System.out.println("Exiting");
                            scanner.close();
                            return;
                        default:
                            System.out.println("Invalid choice, please try again.");
                    }
                } catch (EmployeeNotFoundException | ProjectNotFoundException e) {
                    System.err.println(e.getMessage());
                }
            }
        }
    
        private static void addEmployee(Scanner scanner) {
            System.out.println("Enter Employee details (id, name, designation, gender, salary, project_id):");
            int employeeId= scanner.nextInt();
            String name = scanner.next();
            String designation = scanner.next();
            char gender = scanner.next().charAt(0);
            double salary = scanner.nextDouble();
            int projectId = scanner.nextInt();
    
            Employee employee = new Employee(employeeId, name, designation,gender, salary, projectId);
            if (repository.createEmployee(employee)) {
                System.out.println("Employee added successfully.");
            } else {
                System.out.println("Failed to add employee.");
            }
        }
    
        private static void addProject(Scanner scanner) {
            System.out.println("Enter Project details (Projectid, projectName, description, startDate, status):");
            int projectId = scanner.nextInt();
            String projectName = scanner.next();
            String description = scanner.next();
            Date startDate = new Date(); 
            String status = scanner.next();
    
            Project project = new Project(projectId, projectName, description, startDate, status);
            if (repository.createProject(project)) {
                System.out.println("Project added successfully.");
            } else {
                System.out.println("Failed to add project.");
            }
        }
    
        private static void addTask(Scanner scanner) {
            System.out.println("Enter Task details (task_id, task_name, project_id, employee_id, status):");
            int taskId = scanner.nextInt();
            String taskName = scanner.next();
            int projectId = scanner.nextInt();
            int employeeId = scanner.nextInt();
            String status = scanner.next();
    
            Task task = new Task(taskId, taskName, projectId, employeeId, status);
            if (repository.createTask(task)) {
                System.out.println("Task added successfully.");
            } else {
                System.out.println("Failed to add task.");
            }
        }
    
        private static void assignProjectToEmployee(Scanner scanner) throws EmployeeNotFoundException, ProjectNotFoundException {
            System.out.println("Enter Project ID and Employee ID to assign:");
            int projectId = scanner.nextInt();
            int employeeId = scanner.nextInt();
            if (repository.assignProjectToEmployee(projectId, employeeId)) {
                System.out.println("Project assigned to employee successfully.");
            } else {
                System.out.println("Failed to assign project to employee.");
            }
        }
    
        private static void assignTaskInProjectToEmployee(Scanner scanner) throws EmployeeNotFoundException, ProjectNotFoundException {
            System.out.println("Enter Task ID, Project ID, and Employee ID to assign:");
            int taskId = scanner.nextInt();
            int projectId = scanner.nextInt();
            int employeeId = scanner.nextInt();
            if (repository.assignTaskInProjectToEmployee(taskId, projectId, employeeId)) {
                System.out.println("Task assigned to employee within project successfully.");
            } else {
                System.out.println("Failed to assign task within project to employee.");
            }
        }
    
        private static void deleteEmployee(Scanner scanner) throws EmployeeNotFoundException {
            System.out.println("Enter Employee ID to delete:");
            int employeeId = scanner.nextInt();
            if (repository.deleteEmployee(employeeId)) {
                System.out.println("Employee deleted successfully.");
            } else {
                System.out.println("Failed to delete employee.");
            }
        }
    
        private static void deleteProject(Scanner scanner) throws ProjectNotFoundException {
            System.out.println("Enter Project ID to delete:");
            int projectId = scanner.nextInt();
            if (repository.deleteProject(projectId)) {
                System.out.println("Project deleted successfully.");
            } else {
                System.out.println("Failed to delete project.");
            }
        }
    
        private static void listAllTasks(Scanner scanner) {
            System.out.println("Enter Employee ID and Project ID to list tasks:");
            int employeeId = scanner.nextInt();
            int projectId = scanner.nextInt();
            List<Task> tasks = repository.getAllTasks(employeeId, projectId);
            if (tasks.isEmpty()) {
                System.out.println("No tasks found.");
            } else {
                for (Task task : tasks) {
                    System.out.println(task);
                }
            }
        }
    }