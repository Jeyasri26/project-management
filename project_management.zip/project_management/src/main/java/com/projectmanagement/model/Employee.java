package com.projectmanagement.model;

public class Employee {
    private int employeeId;
    private String name;
    private String designation;
    private char gender;
    private double salary;
    private int projectId;

    
    public Employee() {
    }

    
    public Employee(int employeeId, String name, String designation, char gender, double salary, int projectId) {
        this.employeeId = employeeId;
        this.name = name;
        this.designation = designation;
        this.gender = gender;
        this.salary = salary;
        this.projectId = projectId;
    }

    // Getters and setters
    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
}
