package com.projectmanagement.exception;

public class ProjectNotFoundException extends Exception{
    public ProjectNotFoundException(String message){
        super(message);
    }
    
}
